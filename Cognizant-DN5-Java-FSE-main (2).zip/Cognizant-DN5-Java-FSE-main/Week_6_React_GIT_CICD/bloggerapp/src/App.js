import React from 'react';

export const books = [
  {id:101, bname:'Master React', price:670},
  {id:102, bname:'Deep Dive into Angular 11 ', price:800},
  {id:103, bname:'Mongo Essentials', price:450}
];

function BookDetails(props) {
  return (
    <div style={{borderLeft: '4px solid green', borderRight: '4px solid green', padding: '0 20px'}} className="st2">
      <h1>Book Details</h1>
      <ul>
        {props.books.map((book) => 
          <div key={book.id}>
            <h3>{book.bname}</h3>
            <h4>{book.price}</h4>
          </div>
        )}
      </ul>
    </div>
  );
}

function BlogDetails() {
  const content = (
    <div>
      <h3>React Learning</h3>
      <b>Stephen Biz</b>
      <p>Welcome to learning React!</p>
      <h3>Installation</h3>
      <b>Schewzdenier</b>
      <p>You can install React from npm.</p>
    </div>
  );
  return <div className="v1"><h1>Blog Details</h1>{content}</div>;
}

function CourseDetails() {
  const coursedet = (
    <div>
      <h2>Angular</h2><b>4/5/2021</b>
      <h2>React</h2><b>6/3/2021</b>
    </div>
  );
  return <div className="mystyle1"><h1>Course Details</h1>{coursedet}</div>;
}

function App() {
  return (
    <div style={{display: 'flex', justifyContent: 'space-around', textAlign: 'center'}}>
      <CourseDetails />
      <BookDetails books={books} />
      <BlogDetails />
    </div>
  );
}
export default App;
