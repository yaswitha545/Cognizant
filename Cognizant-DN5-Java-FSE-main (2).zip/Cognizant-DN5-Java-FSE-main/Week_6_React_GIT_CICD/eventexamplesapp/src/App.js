import React, { useState } from 'react';

function CurrencyConvertor() {
  const [amount, setAmount] = useState('');
  const handleSubmit = (e) => { 
    e.preventDefault(); 
    alert("Converting to Euro Amount is " + (amount * 80)); 
  };
  
  return (
    <div>
      <h2 style={{color:'green'}}>Currency Convertor!!!</h2>
      <form onSubmit={handleSubmit}>
        <label>Amount: <input type="number" onChange={e => setAmount(e.target.value)} /></label><br/><br/>
        <label>Currency: <textarea defaultValue="Euro"></textarea></label><br/><br/>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

function App() {
  const [count, setCount] = useState(5);
  
  const handleIncrement = () => { setCount(count + 1); alert("Hello! Member1"); };
  const handleDecrement = () => setCount(count - 1);
  const sayWelcome = (msg) => alert(msg);
  const onPress = () => alert("I was clicked");

  return (
    <div>
      <p>{count}</p>
      <button onClick={handleIncrement}>Increment</button><br/>
      <button onClick={handleDecrement}>Decrement</button><br/>
      <button onClick={() => sayWelcome('welcome')}>Say welcome</button><br/>
      <button onClick={onPress}>Click on me</button>
      <br/><br/>
      <CurrencyConvertor />
    </div>
  );
}
export default App;
