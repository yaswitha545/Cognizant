import React from 'react';

const players = [
  {name:'Jack', score:50}, {name:'Michael', score:70}, {name:'John', score:40}, {name:'Ann', score:61},
  {name:'Elisabeth', score:61}, {name:'Sachin', score:95}, {name:'Dhoni', score:100}, {name:'Virat', score:84},
  {name:'Jadeja', score:64}, {name:'Raina', score:75}, {name:'Rohit', score:80}
];

const T20Players = ['First Player','Second Player','Third Player'];
const RanjiTrophyPlayers = ['Fourth Player','Fifth Player','Sixth Player'];
const IndianPlayers = [...T20Players, ...RanjiTrophyPlayers];
const IndianTeam = ['Sachin1','Dhoni2','Virat3','Rohit4','Yuvaraj5','Raina6'];

function ListofPlayers({players}) {
  return (
    <ul>
      {players.map((item) => (
        <div key={item.name}>
          <li>Mr. {item.name} <span>{item.score}</span></li>
        </div>
      ))}
    </ul>
  );
}

function Scorebelow70({players}) {
  let players70 = [];
  return (
    <ul>
      {players.map((item) => {
        if(item.score <= 70) {
          players70.push(item);
          return <li key={item.name}>Mr. {item.name} {item.score}</li>;
        }
        return null;
      })}
    </ul>
  );
}

export function OddPlayers([first, , third, , fifth]) { 
  return (
    <div>
      <li>First : {first}</li>
      <li>Third : {third}</li>
      <li>Fifth : {fifth}</li>
    </div>
  ); 
}

export function EvenPlayers([ , second, , fourth, , sixth]) { 
  return (
    <div>
      <li>Second : {second}</li>
      <li>Fourth : {fourth}</li>
      <li>Sixth : {sixth}</li>
    </div>
  ); 
}

function ListofIndianPlayers({IndianPlayers}) {
  return <ul>{IndianPlayers.map((p,i) => <li key={i}>Mr. {p}</li>)}</ul>;
}

function App() {
  var flag = true;
  if(flag === true) {
    return (
      <div>
        <h1>List of Players</h1>
        <ListofPlayers players={players}/>
        <hr/>
        <h1>List of Players having Scores Less than 70</h1>
        <Scorebelow70 players={players}/>
      </div>
    );
  } else {
    return (
      <div>
        <h1>Indian Team</h1>
        <h1>Odd Players</h1>
        {OddPlayers(IndianTeam)}
        <hr/>
        <h1>Even Players</h1>
        {EvenPlayers(IndianTeam)}
        <hr/>
        <h1>List of Indian Players Merged:</h1>
        <ListofIndianPlayers IndianPlayers={IndianPlayers}/>
      </div>
    );
  }
}
export default App;
