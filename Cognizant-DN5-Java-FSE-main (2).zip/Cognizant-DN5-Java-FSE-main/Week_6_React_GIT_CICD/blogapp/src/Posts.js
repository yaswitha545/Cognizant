import React from 'react';
import Post from './Post';

class Posts extends React.Component {
  constructor(props){ 
    super(props); 
    this.state = { posts: [], error: null }; 
  }
  
  loadPosts() { 
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(r => r.json())
      .then(data => this.setState({ posts: data.slice(0, 5) }))
      .catch(error => this.setState({ error })); 
  }
  
  componentDidMount() { 
    this.loadPosts(); 
  }
  
  componentDidCatch(error, info) { 
    alert("Error: " + error); 
  }
  
  render() { 
    return (
      <div>
        {this.state.posts.map(p => 
          <div key={p.id}>
            <h3>{p.title}</h3>
            <p>{p.body}</p>
          </div>
        )}
      </div>
    ); 
  }
}
export default Posts;
