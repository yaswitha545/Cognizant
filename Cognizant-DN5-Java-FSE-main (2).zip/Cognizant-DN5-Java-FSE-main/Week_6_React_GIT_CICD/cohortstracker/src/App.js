import React from 'react';
import styles from './CohortDetails.module.css';

function App() {
  const cohorts = [
    {id:1, name:'INTADMDF10 -.NET FSD', start:'22-Feb-2022', status:'Scheduled', coach:'Aathma', trainer:'Jojo Jose'},
    {id:2, name:'ADM21JF014 -Java FSD', start:'10-Sep-2021', status:'Ongoing', coach:'Apoorv', trainer:'Elisa Smith'},
    {id:3, name:'CDBJF21025 -Java FSD', start:'24-Dec-2021', status:'Ongoing', coach:'Aathma', trainer:'John Doe'}
  ];
  return (
    <div>
      <h1>Cohorts Details</h1>
      {cohorts.map(c => (
        <div key={c.id} className={styles.box}>
          <h3 style={{color: c.status === 'Ongoing' ? 'green' : 'blue'}}>{c.name}</h3>
          <dl>
            <dt>Started On</dt><dd>{c.start}</dd>
            <dt>Current Status</dt><dd>{c.status}</dd>
            <dt>Coach</dt><dd>{c.coach}</dd>
            <dt>Trainer</dt><dd>{c.trainer}</dd>
          </dl>
        </div>
      ))}
    </div>
  );
}
export default App;
